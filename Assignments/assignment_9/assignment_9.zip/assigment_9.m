% Assignment 9 for the class Data Science for Human Factors:
% Input/Output Specials
%
% Team:

scores = 0;

%% 1) 4.5
% Plot an animated decorated christmas tree and save it as a gif :)
% Ideas: presents beneath, some decoration, maybe a star on top, snow...
% Animations could be lights or falling snow or anything else you think would 
% be nice in such a situation :)

% Hint: the fill function creates areas filled with color. In 3D you can
% use surf and patch

%% a) 3P
% Plot the christmas tree with trunk and green stuff (1P), 
% decoration, whatever you think is nice, (1P), and nice presents (1P)


%% b) 1.5P
% Animate the tree in some way (0.75P) and save as a gif (0.75P). 



%% 
scores = 0