% test_greater_than_one 

function randvec = test_greater_than_one(n_randvec, mu, sigma)
