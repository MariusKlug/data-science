% compare_SEMs 
%
% Input:
% 
% Output:
%
% Usage:
%
% Author: 
%
% See also: 

function [randmat, MEANs, SDs, SEMs] = compare_SEMs(n_randvec, n_repetitions, mu, sigma)
