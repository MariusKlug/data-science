% my_median

function res_median = my_median(input_data)
