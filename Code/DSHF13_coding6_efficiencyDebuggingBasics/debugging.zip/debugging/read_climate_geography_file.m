% b) 0.75P
%
% read_climate_geography_file reads in a climate geography metatada file
% and stores station ID, name, latitude, longitude, and altitude in a struct.
% The file must be in the format as can be found by the Deutscher Wetterdienst
% example files can be downloaded here:
%
% https://www.dwd.de/DE/leistungen/klimadatendeutschland/klarchivtagmonat.html
%
% Input:
%   filepath            - Correct path to the file (character array)
% 
% Output:
%   climate_metadata    - struct with name, ID, latitude, longitude, and altitude
%
% Usage:
% climate_metadata = read_climate_geography_file([pwd '\klarchiv_00433_daily_his\Metadaten_Geographie_00433.txt']);
%
% Author: Marius Klug, bpn.tu-berlin.de, 2018
%   This function is free for any kind of distribution and usage!
%
% See also: extract_climate_data

function climate_metadata = read_climate_geography_file(filepath)

%-----------------------
% checks
%-----------------------

% we need a check to display the help and if the filepath is correct
if nargin == 0
    help read_climate_geography_file
    return
end

if ~ischar(filepath)
    error('Filepath must be a character array.')
end

% open file
fid = fopen(filepath,'r');

% check if a file was actually found.
% HINT: what does fopen return when no file is found?
if fid == -1
    error('No file was found. Make sure your filepath is correct.')
end

%-----------------------
% computation
%
% we want to loop through each line in the file.
% first we need to find out which columns contain the 
% relevant values for us, then search the next line for 
% the content and store it in a struct to return.
%
% relevant info is:
% name, ID, latitude, longitude, and altitude
% these should also be the fields in your struct!
%-----------------------

% initialize target columns with 0
id_col = 0;
name_col = 0;
lat_col = 0;
long_col = 0;
alt_col = 0;

% loop through the file until end of file is reached
while ~feof(fid) 
    
    % read a line ("file get line")
    aline = fgetl(fid); 
    
    % split the line with the right delimiter
    aline_split = strsplit(aline,';');
    
    % check if the line contains a name, id, latitude, and longitude
    % the information is in german so you need to check it and see
    % how they wrote it exactly. it's okay to hard code here 
    % because this function is specific for this kind of file.
    if any(strcmpi('Stationsname',aline_split)) && ...
            any(strcmpi('Stations_ID',aline_split)) && ...
            any(strcmpi('Geogr.Breite',aline_split)) && ...
            any(strcmpi('Geogr.Laenge',aline_split)) && ...
            any(strcmpi('Stationshoehe',aline_split))
        
        % find the column which contains the name
        name_col = find(strcmpi('Stationsname',aline_split));
        
        % find the column which contains the id
        id_col = find(strcmpi('Stations_ID',aline_split));
        
        % find the column which contains the latitude
        lat_col = find(strcmpi('Geogr.Breite',aline_split));
        
        % find the column which contains the longitude
        long_col = find(strcmpi('Geogr.L?nge',aline_split));
        
        % find the column which contains the altitude
        alt_col = find(strcmpi('Stationshoehe',aline_split));
       
    else
        % check if all columns are not 0
        % -> that means we know where to look and can store the information
        if all([id_col name_col lat_col long_col alt_col])
            
            % store the result information
            % Hint: strtrim removes leading and trailing whitespaces
            % strtrim is not necessary before str2num
            climate_metadata.ID             = str2num(aline_split{id_col});
            climate_metadata.name           = strtrim(aline_split{name_col});
            climate_metadata.latitude       = str2num(aline_split{lat_col});
            climate_metadata.longitude      = str2num(aline_split{long_col});
            climate_metadata.altitude       = str2num(aline_split{alt_col});
            
        end
        
    end
end

% don't forget to close the file after you finish it
fclose(fid); 

% check if your loop has actually found a result 
% this means that the climate_metadata variable must exist.
% throw an error otherwise
if ~exist('climate_metadata','var')
    error('Could not find the relevant information in the file.')
end