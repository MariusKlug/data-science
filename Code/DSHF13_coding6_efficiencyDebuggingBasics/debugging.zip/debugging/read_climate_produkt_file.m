% c) 0.5P
%
% read_climate_produkt_file reads in a climate geography produkt file
% and stores the data values for date, air pressure, aur temperature,
% and precipitation in a struct.
% The file must be in the format as can be found by the Deutscher Wetterdienst
% example files can be downloaded here:
%
% https://www.dwd.de/DE/leistungen/klimadatendeutschland/klarchivtagmonat.html
% 
% an explanation of the used abbreviations can be found here:
% 
% https://www.dwd.de/DE/leistungen/klimadatendeutschland/beschreibung_tagesmonatswerte.html?nn=16102&lsbId=526270
%
% Input:
%   filepath            - Correct path to the file (character array)
% 
% Output:
%   climate_data        - struct array with date, pressure, temperature, and precipitation
%
% Usage:
% climate_metadata = read_climate_geography_file([pwd '\klarchiv_00433_daily_his\Metadaten_Geographie_00433.txt']);
%
% Author: Marius Klug, bpn.tu-berlin.de, 2018
%   This function is free for any kind of distribution and usage!
%
% See also: extract_climate_data

function climate_data = read_climate_produkt_file(filepath)

%-----------------------
% checks
%-----------------------

% we need a check to display the help and if the filepath is correct
if nargin == 0
    help read_climate_produkt_file
    return
end

if ~ischar(filepath)
    error('Filepath must be a character array.')
end

% open file
fid = fopen(filepath,'r');

% check if a file was actually found.
% HINT: what does fopen return when no file is found?
if fid == -1
    error('No file was found. Make sure your filepath is correct.')
end

%-----------------------
% computation
%
% we want to loop through each line in the file.
% first we need to find out which columns contain the 
% relevant values for us, then search all following
% lines for the respective content and store this content 
% in a struct array.
%
% relevant info is:
% date, pressure, temperature, and precipitation
% these should also be the fields in your struct!
%-----------------------

% initalize empty cell array
file_data = cell(1,0);

% initalize target columns with 0
date_col = 0;
pressure_col = 0;
temperature_col = 0;
precipitation_col = 0;

% since we know the structure of this file we can for performance 
% reasons already take the info of the first line
% -> no need to test this for each line
aline = fgetl(fid); 
aline_split = strsplit(aline,',');

% find the column which contains the name
% change the following lines to be better prepared for leading 
% whitespaces. make sure it works without them (e.g. it should
% work with 'PM' instead with '  PM')
date_col            = find(strcmpi('MESSDATUM',strtrim(aline_split)));
pressure_col        = find(strcmpi('PM',strtrim(aline_split)));
temperature_col     = find(strcmpi('TMK',strtrim(aline_split)));
precipitation_col   = find(strcmpi('RSK',strtrim(aline_split)));

% we need a row here, because we store information of many rows
% in a struct array and need to know which index we are at for
% each iteration in the while loop
struct_index = 0;

% loop through the file until end of file is reached
while ~feof(fid) 
    
    % read a line ("file get line")
    aline = fgetl(fid); 
    
    % split the line with the right delimiter
    aline_split = strsplit(aline,';');
    
    % store the result information in the struct
    climate_data(struct_index).date                = str2num(aline_split{date_col});
    climate_data(struct_index).pressure            = str2num(aline_split{pressure_col});
    climate_data(struct_index).temperature         = str2num(aline_split{temperature_col});
    climate_data(struct_index).precipitation       = str2num(aline_split{precipitation_col});

    struct_index = struct_index + 1;
end

% don't forget to close the file after you finish it
fclose(fid);

% check if your loop has actually found a result 
% this means that the climate_data variable must exist.
% throw an error otherwise
if ~exist('climate_data','var')
    error('Could not find the relevant information in the file.')
end