function  [channels_saved] = ravi_tool(plexon_base_filename)
% 
% Filter for Heart Rate and Heart Rate Variability,        
%            Blink detection
%            Pupil Size
%
% 
%    Use ECG and raw pupil data to generate 7 new external analog signals.
%    These channels provide continuous HR and pupil size information
%
%    V 1.0   2 Oct   2009    Adapted from calc_HR_pupil_size() V1.6 by Ravi Chacko  
%    V 1.1   2 Oct   2009    Redefined analog channels.
%    V 1.2   5 Oct   2009    Reorganized to handle any combination of available analog data
%    V 2.0   6 Oct   2009    Room for respiratory rate, scr markers
%    V 2.1   6 Oct   2009    Accepts either base file name or file name with .plx extension
%    V 2.2   8 Oct   2009    Now using  write_external_ad() to store file. Checks for missing data file.
%    V 2.5   8 Oct   2009    Fixed stored channel number (needs to be -1 for zero-based numbering).
%    V 2.6  13 Oct   2009    Fixed tests for available analog data.  Subtracted 1 in two wrong places.
%    V 2.7   9 Nov   2009    Blink, HRV, and HR Goodness analog data vectors were transposed. Functions fixed.
%
%
% INPUT:
%   plexon_base_filename (extension will be ignored)   reads .PLX and creates .MAT using a variable named EC
%
%  Analog Channel Mapping
%  Original Plexon file:
% Type  Plexon   Cortex  Decimate  S/sec   Signal
%  A    17         3       1       1000    Eye X 
%  A    18         4       1       1000    Eye Y 
%  E    19         5       20      50      Raw pupil 1 
%  E    20         6       20      50      Raw pupil 2 (if available)
%  E    21         2       20      50      Raw SCR 
%  E    22         1       10      100     Raw HR 
%       23         --      --      1000    Lick sensor 1
%       24         --      --      1000    Lick sensor 2
%
%  New channels created:
%  X    30         7       20      50      Best available pupil size 
%  X    31         8       20      50      Blink marker 
%  X    32         9       20      50      Best available HR
%  X    33        10       20      50      HR goodness of fit
%  X    34        11       20      50      Best available HRV
%  X    35        12       20      50      Best available Respiratory signal
%  X    36        13       20      50      Best available Respiratory rate
%  X    37        14       20      50      Best available SCR 
%  X    38        15       20      50      SCR markers
%
%
% OUTPUT:
%   channels_saved     list of channel numbers with non-zero data that were saved
%                      most complete list would be [30:38]   
%                         
% NEW FILE CREATED:
%   <plexon_filename>.MAT        External analog channel file
%
% EXAMPLE USAGE:
% [channels_saved] = ravi_tool('il2041a');  % remember, do not include the .plx extention
%

software_version=2.5;

channels_saved=[];
channel_entry=0;
minimum_analog_file_size=100;  % at least 100 samples

% Plexon channels
eye_x  =  17;
eye_y  =  18;
pupil_1=  19;
pupil_2=  20;
rawSCR =  21;
rawHR  =  22;
lick_1 =  23;
lick_2 =  24;

% External channels to create
best_pupil  = 30;   
blinks      = 31;   
best_HR     = 32;  
HR_goodness = 33;  
best_HRV    = 34;   
best_respiratory = 35;   
respiratory_rate = 36;    
best_SCR    = 37;   
SCR_markers = 38;   

% force clean base file name
if isempty(plexon_base_filename)
   fprintf(' - ravi_tool - v%2.1f  ERROR: File name missing\n',software_version);
   return;
else
   [path, name, ext, ver]=fileparts(plexon_base_filename);
   base_filename=fullfile(path,name);
   plexon_file_name=fullfile(path,[name '.plx']);
   external_file_name=fullfile(path,[name '.mat']);
   fprintf(' - ravi_tool - v%2.1f  FILE: %s\n',software_version,plexon_file_name); 
end

% ---   Check to see if we have any data at all ------ %

try
   [n,counts]=plx_adchan_samplecounts(plexon_file_name);   % analog channels in the file
catch
   fprintf('  file not found\n');
   return;  
end
available_channels=find(counts >= minimum_analog_file_size)';  % skip channels with no data
channels=available_channels(find((available_channels>=17) & (available_channels<=24)));  % use these chans 
if isempty(channels)
   fprintf('  Little or no data found\n');
   return;
end

% ---   Initialize External analog channel variable. ------ %
% ---   Place zeros into every channel ------ %

% Read first available channel, usually EOG channel.
% Note, every time we use the Plexon CDK tool we have to subtract 1 from the channel number
[adfreq, n, ts, fn, ad] = plx_ad(plexon_file_name,channels(1)-1);  % -1 for CDK tools

% Initialize EC variable, which becomes the external analog data.
% F provides a structure for initialization of array EC
F.ch=38-1;       % last channel (9th entry), -1 for CDK 
F.adfreq=adfreq;
F.n=n;
F.ts=ts;
F.fn=fn;
F.ad=zeros(size(ad));  % initialize with zeros for every sample.

% ---   Pupil size ------ %

if ~isempty(find(channels==pupil_1, 1))
   fprintf('Calculating Pupil Size\n');
   % read first pupil channel
   [adfreq, n, ts, fn, ad] = plx_ad(plexon_file_name,pupil_1-1);
   if isempty(find(channels==pupil_2, 1))
      iPR=ad;
   else
     [adfreq2, n2, ts2, fn2, ad2] = plx_ad(plexon_file_name,pupil_2-1);
      iPR = max(ad,ad2);
   end
   % Get PS (pupil size, blinks removed) and BL (blink markers) from pupil data
   [PS,BL] = blinkextract(iPR,2);   % 2 standard deviations for blink thereshold

   % Store best pupil size
   channel_entry=channel_entry+1;
   EC(channel_entry)=F;  % initialize
   EC(channel_entry).ch=best_pupil-1;
   EC(channel_entry).ad=PS;
   % Store blink markers
   channel_entry=channel_entry+1;
   EC(channel_entry)=F;  % initialize
   EC(channel_entry).ch=blinks-1;
   EC(channel_entry).ad=BL;

   channels_saved=[channels_saved best_pupil blinks];
end


% ---   ECG HRV ------ %

if ~isempty(find(channels==rawHR, 1))
   [adfreq, n, ts, fn, ad] = plx_ad(plexon_file_name,rawHR-1);
   % ECG2HR() function returns:
   %  HRV           continuous HRV value, including noise
   %  eHRV          continuous HRV value, with extream values clamped to the mean
   %  goodness      z score
   %  cutoff        z score cutoff value used to exclude beats
   %  percentfail   percent of data that was excluded
   [HRV,eHRV, goodness,cutoff,percentfail] = ECG2HR(ad,n,adfreq);

   % Store best HR (just original signal right now)   
   channel_entry=channel_entry+1;
   EC(channel_entry)=F;  % initialize
   EC(channel_entry).ch=best_HR-1;
   EC(channel_entry).ad=ad;
   % Store HRV quality (goodness)
   channel_entry=channel_entry+1;
   EC(channel_entry)=F;  % initialize
   EC(channel_entry).ch=HR_goodness-1;
   EC(channel_entry).ad=goodness;
   % Store HRV
   channel_entry=channel_entry+1;
   EC(channel_entry)=F;  % initialize
   EC(channel_entry).ch=best_HRV-1;
   EC(channel_entry).ad=eHRV;

   channels_saved=[channels_saved best_HR HR_goodness best_HRV];

   % Store           NO RESPIRATORY SIGNAL PROCESSING !
%   channel_entry=channel_entry+1;
%   EC(channel_entry)=F;  % initialize
%   EC(channel_entry).ch=best_respiratory-1;
%   EC(channel_entry).ad=???????;

   % Store             NO RESPIRATORY RATE SIGNAL !
%   channel_entry=channel_entry+1;
%   EC(channel_entry)=F;  % initialize
%   EC(channel_entry).ch=respiratory_rate-1;
%   EC(channel_entry).ad=???????;

%   channels_saved=[channels_saved best_respiratory respiratory_rate];

end % ECG HRV


% ---   SCR ------ %
if ~isempty(find(channels==rawSCR, 1))

   fprintf('Calculating SCR\n');
   [adfreq, n, ts, fn, ad] = plx_ad(plexon_file_name,rawSCR-1);

   % Store best SCR      
   channel_entry=channel_entry+1;
   EC(channel_entry)=F;  % initialize
   EC(channel_entry).ch=best_SCR-1;
   EC(channel_entry).ad=ad;  % THIS IS ALL WE KNOW HOW TO DO 

   channels_saved=[channels_saved best_SCR];

   % Store             NO SCR MARKERS !
%   channel_entry=channel_entry+1;
%   EC(channel_entry)=F;  % initialize
%   EC(channel_entry).ch=SCR_markers-1;
%   EC(channel_entry).ad=???????;

%   channels_saved=[channels_saved SCR_markers];

end % SCR

write_external_ad(external_file_name, EC);

fprintf('Channels saved: ');
for i=1:length(channels_saved)
   fprintf('%2d ',channels_saved(i));
end
fprintf('\n');


end % END ravi_tool

