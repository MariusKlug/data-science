function [HRs,eHRs, goodness,cutoff,percentfail] = ECG2HR(ECGs,nECGs,samplerate)
% ECG2HR takes as input a cell array of ECG signals and converts it to a
% cell array of HR signals of the same dimensions. It also outputs a
% corresponding cell array depicting goodness of fit for each HR. The 
% goodness measure is based on the z value 
%
%    V 1.0   17 July 2009    Ravi Chacko  
%    V 1.1   24 Aug  2009    Andy Mitz, documentation only
%    V 1.5   25 Aug  2009    samplerate and n are parameters
%    V 1.6   25 Aug  2009    More detailed reporting during processing. Some error trapping
%    V 2.0    2 Oct  2009    Explicitly calls findpeaks2007b.m
%    V 2.7    9 Nov  2009    Return values were transposed relative to input arrays. Fixed.
%
% INPUTS
%    ECGs             cell array of ECG samples
%    nECGs            number of samples
%    samplerate       sample rate
% OUTPUTS
%     HRs             array    continuous HR value, including noise
%     eHRs            array    continuous HR value, but with extream values clamped to the mean
%     goodness        array    z score
%     cutoff          scalar   the arbitrary cutoff value used to exclude beats
%     percentfail     scalar   percent of data that was excluded
%    
%
%

Wn=[10/samplerate,50/samplerate];  
%  Bandpass filter 10-50 Hz
[B,A] = butter(1,Wn);          
cECG = filtfilt(B,A,ECGs);
%  Envelope detection
hECG = abs(hilbert(diff(cECG))); % envelope of filtered ECG
%  Envelope peaks
[pks,loc] = findpeaks2007b(hECG,'minpeakdistance',250);  

%  Use locations of peaks to calculate HRV
[HRs,eHRs,goodness,cutoff, percentfail] = HeartRate(cECG,loc,samplerate); %see subfunction

%  Transpose row vectors to column vectors (to match dimensions of ECGs)
HRs=HRs'; 
eHRs=eHRs';
goodness=goodness';

end % end of main


%% ---------- Function HeartRate() ------------------------------
function [HRs,eHRs,goodness,variability_cutoff, percentfail] = HeartRate(ECG,positions,samplerate)
% Subfunction to calculate Heart Rate, expected Heart Rate and goodness of
% fit, all of equal dimensions as the original ECG

variability_cutoff=100;

fprintf('Calculating HR variability...   ');

goodness = zeros(1,length(ECG));
eHRs = zeros(1,length(ECG));
diffs = zeros(1,length(positions)-1);
middles = zeros(1,length(positions)-1); %positions for the 1st deriv
zmiddles = zeros(1,length(middles)-1); %for the second deriv
hrs = zeros(1,length(positions)-1);

% find the differences between peak locations and the middles
for count = 2:length(positions)
    diffs(count-1)= abs(positions(count)-positions(count-1)); %in samples
    middles(count-1) = round((positions(count-1)+positions(count))/2);
    if count>2
        zmiddles(count-2) = (middles(count-1)+middles(count-2))/2;
    end
end

hrs = (samplerate./diffs)*60; %heart rates in beats per minute
hrmean = mean(hrs);
fprintf('Mean Heart Rate= %5.1f\n',hrmean);
hrstd = std(hrs);
hrste = hrstd/sqrt(length(hrs));

xi = 1:length(ECG);
%   Interpolate (raw) HR
HRs=interp1(middles,hrs,xi);

% rate values 
% z = ones(1,length(HRs));
% z = (hrs-hrmean)./dhrste
% this z-stat is based on the differences between hrs
dhrs = diff(hrs);
dhrmean = mean(dhrs);
dhrste = std(dhrs)/sqrt(length(dhrs));

z = ones(1,length(dhrs));
z = (dhrs-dhrmean)./dhrste; %z test from stat 
z= abs(z);
goodness = (interp1(zmiddles,abs(z),xi));
ehrs = hrs;

% recall for two-tailed normal distribution
% 99% 2.575
% 95% conf - z <=1.960 
% 90
% 

% The following segment is how the estimated HR is calculated, currently it
% starts with an arbitrary cutoff. Values above this cutoff are clamped
% to the mean. However, no more than 20% of the signal will be clamped
% cutoff=100;
% percentfail = length(find(abs(z)>cutoff))/length(dhrs);
% while percentfail>.05 %does not allow clamping on more than 5%
%     cutoff=cutoff+1;
%     percentfail = length(find(abs(z)>cutoff))/length(dhrs);
% end

%  Percent beyond cutoff
percentfail = length(find(abs(z)>variability_cutoff))/length(dhrs);
ols = find(z > variability_cutoff);
ehrs(ols)=hrmean;
% Clamp outliers to mean and interpolate to produce final HR signal
eHRs = interp1(middles,ehrs,xi);

end % optional end of HeartRate()